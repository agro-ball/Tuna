package com.tunavpn.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import com.tunavpn.app.MainActivity
import com.tunavpn.app.Prefs
import com.tunavpn.app.R
import com.tunavpn.app.Strategies
import com.tunavpn.app.Strategy
import com.tunavpn.app.net.DomainLists
import com.tunavpn.app.net.PacketUtils
import com.tunavpn.app.net.TcpRelay
import com.tunavpn.app.net.TelegramWsProxy
import com.tunavpn.app.net.UdpRelay
import java.io.FileInputStream
import java.io.FileOutputStream

class TunaVpnService : VpnService() {

    companion object {
        const val ACTION_START = "com.tunavpn.app.START"
        const val ACTION_STOP = "com.tunavpn.app.STOP"
        const val ACTION_STRATEGY = "com.tunavpn.app.STRATEGY"
        private const val CHANNEL = "tuna_vpn"
        private const val NOTIF_ID = 1

        /** Приложения, которые идут через туннель, когда выбрано «только YouTube и Telegram». */
        private val TARGET_APPS = listOf(
            "com.google.android.youtube",
            "com.google.android.apps.youtube.music",
            "com.google.android.youtube.tv",
            "app.revanced.android.youtube",
            "org.telegram.messenger",
            "org.telegram.messenger.web",
            "org.telegram.plus",
            "org.thunderdog.challegram",
            "nekox.messenger",
            "tw.nekomimi.nekogram"
        )

        @Volatile var isRunning = false
            private set
        @Volatile var startedAt = 0L
            private set
        @Volatile var onLog: ((String) -> Unit)? = null

        private val logs = ArrayList<String>()

        fun log(msg: String) {
            synchronized(logs) {
                logs.add(msg)
                if (logs.size > 300) logs.removeAt(0)
            }
            onLog?.invoke(msg)
        }

        fun logSnapshot(): List<String> = synchronized(logs) { ArrayList(logs) }
    }

    private lateinit var prefs: Prefs
    @Volatile private var strategy: Strategy = Strategies.ALL[0]

    private var tun: ParcelFileDescriptor? = null
    private var tunOut: FileOutputStream? = null
    private var tcp: TcpRelay? = null
    private var udp: UdpRelay? = null
    private var tg: TelegramWsProxy? = null
    private var tunThread: Thread? = null
    private var tickThread: Thread? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopEngine()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_STRATEGY -> {
                strategy = Strategies.byId(intent.getStringExtra("id") ?: "auto")
                log("Протокол: ${strategy.name}")
                if (isRunning) updateNotification(strategy.name)
            }
            ACTION_START -> startVpn()
        }
        return START_NOT_STICKY
    }

    private fun startVpn() {
        stopEngine() // на случай перезапуска с новыми настройками
        prefs = Prefs(this)
        strategy = Strategies.byId(prefs.strategyId)
        DomainLists.load(this)
        createChannel()
        startForeground(NOTIF_ID, buildNotification(strategy.name))

        val b = Builder()
            .setSession("tunaVPN")
            .addAddress("10.8.0.2", 32)
            .addRoute("0.0.0.0", 0)
            .addDnsServer("1.1.1.1")
            .addDnsServer("8.8.8.8")
            .setMtu(1500)
            .setBlocking(false)

        var scoped = false
        if (!prefs.allApps) {
            for (pkg in TARGET_APPS) {
                try {
                    b.addAllowedApplication(pkg)
                    scoped = true
                } catch (_: Exception) {
                }
            }
        }
        if (!scoped) {
            // все приложения, кроме самого tunaVPN (чтобы не зациклиться)
            try { b.addDisallowedApplication(packageName) } catch (_: Exception) {}
        }

        val pfd = try { b.establish() } catch (e: Exception) { null }
        if (pfd == null) {
            log("Не удалось создать туннель")
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return
        }
        tun = pfd
        val out = FileOutputStream(pfd.fileDescriptor)
        tunOut = out

        val write: (ByteArray) -> Unit = { pkt ->
            synchronized(out) {
                try { out.write(pkt) } catch (_: Exception) {}
            }
        }

        tcp = TcpRelay(this, { strategy }, { prefs.domainOnly }, write) { log(it) }
        udp = UdpRelay(this, { prefs.doh }, write) { log(it) }

        if (prefs.telegram) {
            val secret = prefs.tgSecretHex.chunked(2).map { it.toInt(16).toByte() }.toByteArray()
            tg = TelegramWsProxy(this, secret) { log(it) }.also { it.start() }
        }

        startedAt = SystemClock.elapsedRealtime()
        isRunning = true
        log(if (scoped) "Туннель: только YouTube и Telegram" else "Туннель: все приложения")
        log("Протокол: ${strategy.name}")

        val input = FileInputStream(pfd.fileDescriptor)
        tunThread = Thread({ tunLoop(input) }, "tuna-tun").also { it.isDaemon = true; it.start() }
        tickThread = Thread({
            try {
                while (true) {
                    Thread.sleep(10_000)
                    tcp?.cleanup()
                    udp?.cleanup()
                }
            } catch (_: InterruptedException) {
            }
        }, "tuna-tick").also { it.isDaemon = true; it.start() }
    }

    private fun tunLoop(input: FileInputStream) {
        val buf = ByteArray(32767)
        var idle = 1L
        try {
            while (isRunning && !Thread.currentThread().isInterrupted) {
                val n = input.read(buf)
                if (n < 0) break
                if (n == 0) {
                    Thread.sleep(idle)
                    if (idle < 15) idle++
                    continue
                }
                idle = 1
                if (n < 20 || PacketUtils.ipVersion(buf) != 4) continue
                val pkt = buf.copyOf(n)
                when (PacketUtils.ipProto(pkt)) {
                    6 -> tcp?.handle(pkt)
                    17 -> udp?.handle(pkt)
                }
            }
        } catch (_: InterruptedException) {
        } catch (e: Exception) {
            if (isRunning) log("Туннель остановлен: ${e.message}")
        }
    }

    private fun stopEngine() {
        val was = isRunning
        isRunning = false
        tunThread?.interrupt(); tunThread = null
        tickThread?.interrupt(); tickThread = null
        tcp?.shutdown(); tcp = null
        udp?.shutdown(); udp = null
        tg?.stop(); tg = null
        try { tun?.close() } catch (_: Exception) {}
        tun = null
        tunOut = null
        if (was) log("tunaVPN остановлен")
    }

    override fun onRevoke() {
        stopEngine()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        stopEngine()
        super.onDestroy()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL, "tunaVPN", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    private fun updateNotification(protocol: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(protocol))
    }

    private fun buildNotification(protocol: String): Notification {
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, TunaVpnService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setContentTitle("tunaVPN")
            .setContentText("Протокол: $protocol")
            .setSmallIcon(R.drawable.ic_notif)
            .setContentIntent(open)
            .addAction(R.drawable.ic_notif, "Стоп", stop)
            .setOngoing(true)
            .build()
    }
}
