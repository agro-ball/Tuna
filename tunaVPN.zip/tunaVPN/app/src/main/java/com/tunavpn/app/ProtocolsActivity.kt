package com.tunavpn.app

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.tunavpn.app.service.TunaVpnService
import com.tunavpn.app.ui.StrategyAdapter

/** Отдельная вкладка: список протоколов, который можно листать и выбирать. */
class ProtocolsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_protocols)
        val prefs = Prefs(this)

        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }

        val rv = findViewById<RecyclerView>(R.id.rvStrategies)
        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = StrategyAdapter(Strategies.ALL, prefs.strategyId) { st ->
            prefs.strategyId = st.id
            if (TunaVpnService.isRunning) {
                startService(
                    Intent(this, TunaVpnService::class.java)
                        .setAction(TunaVpnService.ACTION_STRATEGY)
                        .putExtra("id", st.id)
                )
            }
        }
    }
}
