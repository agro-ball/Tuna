package com.tunavpn.app

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.switchmaterial.SwitchMaterial
import com.tunavpn.app.service.TunaVpnService
import com.tunavpn.app.ui.LogAdapter

/** Настройки и журнал. */
class SettingsActivity : AppCompatActivity() {

    private lateinit var logAdapter: LogAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        val prefs = Prefs(this)

        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }

        bind(R.id.swTelegram, prefs.telegram) { prefs.telegram = it; restartIfRunning() }
        bind(R.id.swAllApps, prefs.allApps) { prefs.allApps = it; restartIfRunning() }
        bind(R.id.swDoh, prefs.doh) { prefs.doh = it }
        bind(R.id.swDomain, prefs.domainOnly) { prefs.domainOnly = it }
        bind(R.id.swAutostart, prefs.autostart) { prefs.autostart = it }

        val rvLog = findViewById<RecyclerView>(R.id.rvLogs)
        logAdapter = LogAdapter()
        rvLog.layoutManager = LinearLayoutManager(this)
        rvLog.adapter = logAdapter
    }

    private fun bind(id: Int, value: Boolean, onChange: (Boolean) -> Unit) {
        val sw = findViewById<SwitchMaterial>(id)
        sw.isChecked = value
        sw.setOnCheckedChangeListener { _, v -> onChange(v) }
    }

    /** Часть настроек применяется только при создании туннеля — перезапускаем его. */
    private fun restartIfRunning() {
        if (TunaVpnService.isRunning) {
            startForegroundService(
                Intent(this, TunaVpnService::class.java).setAction(TunaVpnService.ACTION_START)
            )
        }
    }

    override fun onResume() {
        super.onResume()
        TunaVpnService.onLog = { line -> runOnUiThread { logAdapter.add(line) } }
        logAdapter.set(TunaVpnService.logSnapshot())
    }

    override fun onPause() {
        TunaVpnService.onLog = null
        super.onPause()
    }
}
