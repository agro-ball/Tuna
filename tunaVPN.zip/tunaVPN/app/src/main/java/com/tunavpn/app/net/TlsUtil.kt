package com.tunavpn.app.net

object TlsUtil {

    class Sni(val start: Int, val len: Int, val host: String)

    private fun u16(d: ByteArray, p: Int) = ((d[p].toInt() and 0xFF) shl 8) or (d[p + 1].toInt() and 0xFF)

    /** TLS handshake record с ClientHello. */
    fun isClientHello(d: ByteArray): Boolean =
        d.size > 6 && d[0] == 0x16.toByte() && d[1] == 0x03.toByte() && d[5] == 0x01.toByte()

    fun recordLen(d: ByteArray): Int = u16(d, 3)

    fun isHttp(d: ByteArray): Boolean {
        if (d.size < 8) return false
        val s = String(d, 0, 8, Charsets.ISO_8859_1)
        return s.startsWith("GET ") || s.startsWith("POST ") || s.startsWith("HEAD ") ||
            s.startsWith("PUT ") || s.startsWith("OPTIONS")
    }

    /** Позиция значения заголовка Host в HTTP-запросе или -1. */
    fun findHttpHost(d: ByteArray): Int {
        val s = String(d, Charsets.ISO_8859_1)
        val i = s.indexOf("host:", ignoreCase = true)
        return if (i < 0) -1 else i + 6
    }

    fun findSni(d: ByteArray): Sni? {
        try {
            if (!isClientHello(d)) return null
            var p = 5 + 4 + 2 + 32                 // record + handshake header + version + random
            if (p >= d.size) return null
            p += 1 + (d[p].toInt() and 0xFF)       // session id
            if (p + 2 > d.size) return null
            p += 2 + u16(d, p)                     // cipher suites
            if (p >= d.size) return null
            p += 1 + (d[p].toInt() and 0xFF)       // compression methods
            if (p + 2 > d.size) return null
            val extEnd = minOf(d.size, p + 2 + u16(d, p))
            p += 2
            while (p + 4 <= extEnd) {
                val type = u16(d, p)
                val len = u16(d, p + 2)
                p += 4
                if (type == 0) {
                    if (p + 5 > d.size) return null
                    val nameLen = u16(d, p + 3)
                    val s = p + 5
                    if (nameLen <= 0 || s + nameLen > d.size) return null
                    return Sni(s, nameLen, String(d, s, nameLen, Charsets.US_ASCII))
                }
                p += len
            }
        } catch (_: Exception) {
        }
        return null
    }

    /**
     * Делит одну TLS-запись на две записи (внутри полезной нагрузки по смещению q).
     * Результат на 5 байт длиннее исходного.
     */
    fun splitRecord(d: ByteArray, q: Int): ByteArray {
        val plen = minOf(recordLen(d), d.size - 5)
        if (plen < 2) return d
        val q2 = q.coerceIn(1, plen - 1)
        val r2 = plen - q2
        val out = ByteArray(d.size + 5)
        out[0] = d[0]; out[1] = d[1]; out[2] = d[2]
        out[3] = ((q2 shr 8) and 0xFF).toByte(); out[4] = (q2 and 0xFF).toByte()
        System.arraycopy(d, 5, out, 5, q2)
        val o2 = 5 + q2
        out[o2] = d[0]; out[o2 + 1] = d[1]; out[o2 + 2] = d[2]
        out[o2 + 3] = ((r2 shr 8) and 0xFF).toByte(); out[o2 + 4] = (r2 and 0xFF).toByte()
        System.arraycopy(d, 5 + q2, out, o2 + 5, r2)
        val tail = d.size - 5 - plen
        if (tail > 0) System.arraycopy(d, 5 + plen, out, o2 + 5 + r2, tail)
        return out
    }
}
