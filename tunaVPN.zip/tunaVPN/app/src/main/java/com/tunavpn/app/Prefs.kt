package com.tunavpn.app

import android.content.Context
import android.content.SharedPreferences
import java.security.SecureRandom

class Prefs(context: Context) {

    private val sp: SharedPreferences =
        context.applicationContext.getSharedPreferences("tuna_prefs", Context.MODE_PRIVATE)

    var strategyId: String
        get() = sp.getString("strategy", "auto") ?: "auto"
        set(v) { sp.edit().putString("strategy", v).apply() }

    /** Обход Telegram через локальный WebSocket-прокси. */
    var telegram: Boolean
        get() = sp.getBoolean("telegram", true)
        set(v) { sp.edit().putBoolean("telegram", v).apply() }

    var autostart: Boolean
        get() = sp.getBoolean("autostart", false)
        set(v) { sp.edit().putBoolean("autostart", v).apply() }

    /** false = через туннель идут только YouTube и Telegram, true = все приложения. */
    var allApps: Boolean
        get() = sp.getBoolean("all_apps", false)
        set(v) { sp.edit().putBoolean("all_apps", v).apply() }

    /** Шифрованный DNS (DoH) вместо обычного. */
    var doh: Boolean
        get() = sp.getBoolean("doh", true)
        set(v) { sp.edit().putBoolean("doh", v).apply() }

    /** Применять обход только к доменам из списков (YouTube, Telegram и т.д.). */
    var domainOnly: Boolean
        get() = sp.getBoolean("domain_only", false)
        set(v) { sp.edit().putBoolean("domain_only", v).apply() }

    /** Секрет локального Telegram-прокси (генерируется один раз). */
    val tgSecretHex: String
        get() {
            val saved = sp.getString("tg_secret", null)
            if (saved != null && saved.length == 32) return saved
            val b = ByteArray(16)
            SecureRandom().nextBytes(b)
            val fresh = b.joinToString("") { "%02x".format(it) }
            sp.edit().putString("tg_secret", fresh).apply()
            return fresh
        }
}
