package com.tunavpn.app.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.tunavpn.app.R

class LogAdapter : RecyclerView.Adapter<LogAdapter.VH>() {

    private val items = ArrayList<String>()

    class VH(val tv: TextView) : RecyclerView.ViewHolder(tv)

    fun set(list: List<String>) {
        items.clear()
        items.addAll(list.asReversed())
        notifyDataSetChanged()
    }

    fun add(line: String) {
        items.add(0, line)
        if (items.size > 300) items.removeAt(items.size - 1)
        notifyItemInserted(0)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_log, parent, false) as TextView)

    override fun onBindViewHolder(holder: VH, position: Int) {
        holder.tv.text = items[position]
    }

    override fun getItemCount() = items.size
}
