package com.tunavpn.app.net

import com.tunavpn.app.Method
import com.tunavpn.app.Strategies
import java.io.OutputStream
import java.net.Socket
import java.util.concurrent.ConcurrentHashMap

/** Запоминает, какой способ сработал для сервера в режиме «Авто». */
object AutoState {
    private val idx = ConcurrentHashMap<String, Int>()

    fun methodFor(key: String): Method {
        val order = Strategies.AUTO_ORDER
        return order[(idx[key] ?: 0) % order.size]
    }

    fun failed(key: String) {
        idx[key] = ((idx[key] ?: 0) + 1) % Strategies.AUTO_ORDER.size
    }
}

/**
 * Способы отправки первого пакета (ClientHello / HTTP-запрос), которые работают
 * без root: деление на части, TTL-трюк, срочный байт, дробление TLS-записи.
 */
object DpiBypass {

    fun send(sock: Socket, out: OutputStream, data: ByteArray, method: Method) {
        sock.tcpNoDelay = true
        if (TlsUtil.isClientHello(data)) {
            sendTls(sock, out, data, method)
        } else if (TlsUtil.isHttp(data)) {
            sendHttp(sock, out, data, method)
        } else {
            plain(out, data)
        }
    }

    private fun sendTls(sock: Socket, out: OutputStream, data: ByteArray, method: Method) {
        val sni = TlsUtil.findSni(data)
        // смещение в середине имени сайта (или запасное, если SNI не нашли)
        val mid = if (sni != null) sni.start + sni.len / 2 else 40
        when (method) {
            Method.SPLIT -> split(out, data, 1)
            Method.SPLIT_SNI, Method.AUTO -> split(out, data, mid)
            Method.TLSREC -> {
                val q = (mid - 5).coerceAtLeast(1)
                plain(out, TlsUtil.splitRecord(data, q))
            }
            Method.TLSREC_SPLIT -> {
                val q = (mid - 5).coerceAtLeast(1)
                val rec = TlsUtil.splitRecord(data, q)
                split(out, rec, 5 + q)
            }
            Method.OOB -> oob(sock, out, data, mid)
            Method.DISORDER -> disorder(sock, out, data, mid)
        }
    }

    private fun sendHttp(sock: Socket, out: OutputStream, data: ByteArray, method: Method) {
        val h = TlsUtil.findHttpHost(data)
        val pos = if (h > 0) h + 1 else 3
        when (method) {
            Method.OOB -> oob(sock, out, data, pos)
            Method.DISORDER -> disorder(sock, out, data, pos)
            else -> split(out, data, pos)
        }
    }

    private fun plain(out: OutputStream, data: ByteArray) {
        out.write(data)
        out.flush()
    }

    private fun split(out: OutputStream, data: ByteArray, at: Int) {
        if (data.size < 2) return plain(out, data)
        val pos = at.coerceIn(1, data.size - 1)
        out.write(data, 0, pos)
        out.flush()
        pause()
        out.write(data, pos, data.size - pos)
        out.flush()
    }

    private fun oob(sock: Socket, out: OutputStream, data: ByteArray, at: Int) {
        if (data.size < 2) return plain(out, data)
        val pos = at.coerceIn(1, data.size - 1)
        out.write(data, 0, pos)
        out.flush()
        pause()
        try {
            sock.sendUrgentData('a'.code)
        } catch (_: Exception) {
        }
        pause()
        out.write(data, pos, data.size - pos)
        out.flush()
    }

    /**
     * Первая часть уходит с TTL=1 и не доходит до DPI/сервера, вторая — нормально.
     * Потерянную первую часть ядро само перешлёт позже: так порядок частей нарушается.
     */
    private fun disorder(sock: Socket, out: OutputStream, data: ByteArray, at: Int) {
        if (data.size < 2) return plain(out, data)
        val pos = at.coerceIn(1, data.size - 1)
        val old = SockUtil.getTtl(sock) ?: 64
        SockUtil.setTtl(sock, 1)
        out.write(data, 0, pos)
        out.flush()
        pause()
        SockUtil.setTtl(sock, old)
        out.write(data, pos, data.size - pos)
        out.flush()
    }

    private fun pause() {
        try {
            Thread.sleep(3)
        } catch (_: InterruptedException) {
        }
    }
}
