package com.tunavpn.app.net

import android.net.VpnService
import android.util.Base64
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.concurrent.Executors
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory

/**
 * Локальный MTProto-прокси для Telegram.
 *
 *  Telegram ──(MTProto obfuscated2, секрет)──► 127.0.0.1:1443 ──(WebSocket по HTTPS)──► kwsN.web.telegram.org
 *
 * Прямые адреса дата-центров Telegram часто режутся по IP, а адреса веб-версии — нет,
 * поэтому поток заворачивается в WebSocket, как это делает web.telegram.org.
 */
class TelegramWsProxy(
    private val vpn: VpnService,
    private val secret: ByteArray,
    private val log: (String) -> Unit
) {
    companion object {
        const val PORT = 1443
        private val BAD_FIRST_WORDS = setOf(
            0x44414548, 0x54534F50, 0x20544547, 0x4954504F,
            0xEEEEEEEE.toInt(), 0xDDDDDDDD.toInt(), 0x02010316
        )
    }

    private val pool = Executors.newCachedThreadPool()
    private val random = SecureRandom()
    @Volatile private var running = false
    private var server: ServerSocket? = null

    fun start() {
        if (running) return
        running = true
        pool.execute {
            try {
                val ss = ServerSocket()
                ss.reuseAddress = true
                ss.bind(InetSocketAddress(InetAddress.getByName("127.0.0.1"), PORT), 64)
                server = ss
                log("Telegram: прокси слушает 127.0.0.1:$PORT")
                while (running) {
                    val c = ss.accept()
                    pool.execute { handle(c) }
                }
            } catch (e: Exception) {
                if (running) log("Telegram: ошибка прокси — ${e.message}")
            }
        }
    }

    fun stop() {
        running = false
        try { server?.close() } catch (_: Exception) {}
        pool.shutdownNow()
    }

    // ───────────────────────────── клиент Telegram ─────────────────────────────

    private fun handle(client: Socket) {
        var ws: Ws? = null
        try {
            client.tcpNoDelay = true
            val cin = client.getInputStream()
            val cout = client.getOutputStream()

            val init = readFully(cin, 64) ?: return

            // клиент → прокси: ключ = SHA256(prekey + secret), iv = следующие 16 байт
            val cDec = aes(
                sha256(init.copyOfRange(8, 40) + secret),
                init.copyOfRange(40, 56), Cipher.DECRYPT_MODE
            )
            val plainInit = cDec.update(init)
            val tag = le32(plainInit, 56)
            if (tag != 0xDDDDDDDD.toInt() && tag != 0xEEEEEEEE.toInt() && tag != 0xEFEFEFEF.toInt()) {
                log("Telegram: неверный секрет или протокол (проверь ссылку прокси)")
                return
            }
            val dcRaw = (((plainInit[60].toInt() and 0xFF) or (plainInit[61].toInt() shl 8)).toShort()).toInt()
            val dc = Math.abs(dcRaw)
            if (dc !in 1..5) {
                log("Telegram: DC $dcRaw не поддерживается")
                return
            }

            // прокси → клиент: обратный порядок байт
            val rev = init.copyOfRange(8, 56).reversedArray()
            val cEnc = aes(
                sha256(rev.copyOfRange(0, 32) + secret),
                rev.copyOfRange(32, 48), Cipher.ENCRYPT_MODE
            )

            // собственное рукопожатие с сервером Telegram
            val up = makeUpstreamInit(le32(plainInit, 56), dcRaw)

            ws = connectWs(dc, dcRaw < 0)
            if (ws == null) {
                log("Telegram: не удалось открыть WebSocket для DC$dc")
                return
            }
            log("Telegram: DC$dc подключён")
            ws.send(up.init)

            val wsRef = ws
            // сервер → клиент
            pool.execute {
                try {
                    while (true) {
                        val frame = wsRef.recv() ?: break
                        val plain = up.dec.update(frame)
                        val enc = cEnc.update(plain)
                        cout.write(enc)
                        cout.flush()
                    }
                } catch (_: Exception) {
                } finally {
                    try { client.close() } catch (_: Exception) {}
                    wsRef.close()
                }
            }

            // клиент → сервер
            val buf = ByteArray(16384)
            while (true) {
                val n = cin.read(buf)
                if (n < 0) break
                val plain = cDec.update(buf, 0, n)
                wsRef.send(up.enc.update(plain))
            }
        } catch (_: Exception) {
        } finally {
            try { client.close() } catch (_: Exception) {}
            ws?.close()
        }
    }

    private class Upstream(val init: ByteArray, val enc: Cipher, val dec: Cipher)

    private fun makeUpstreamInit(tag: Int, dcRaw: Int): Upstream {
        val init = ByteArray(64)
        while (true) {
            random.nextBytes(init)
            if (init[0] == 0xEF.toByte()) continue
            if (le32(init, 0) in BAD_FIRST_WORDS) continue
            if (le32(init, 4) == 0) continue
            break
        }
        init[56] = tag.toByte()
        init[57] = (tag shr 8).toByte()
        init[58] = (tag shr 16).toByte()
        init[59] = (tag shr 24).toByte()
        init[60] = dcRaw.toByte()
        init[61] = (dcRaw shr 8).toByte()

        val enc = aes(init.copyOfRange(8, 40), init.copyOfRange(40, 56), Cipher.ENCRYPT_MODE)
        val encrypted = enc.update(init)
        val out = init.copyOf()
        // шифруется только хвост (теги и DC); состояние шифра продолжается для потока
        System.arraycopy(encrypted, 56, out, 56, 8)

        val rev = init.copyOfRange(8, 56).reversedArray()
        val dec = aes(rev.copyOfRange(0, 32), rev.copyOfRange(32, 48), Cipher.DECRYPT_MODE)
        return Upstream(out, enc, dec)
    }

    // ───────────────────────────── WebSocket к Telegram ─────────────────────────────

    private fun connectWs(dc: Int, media: Boolean): Ws? {
        val hosts = if (media) {
            listOf("kws$dc-1.web.telegram.org", "kws$dc.web.telegram.org")
        } else {
            listOf("kws$dc.web.telegram.org", "kws$dc-1.web.telegram.org")
        }
        for (host in hosts) {
            var raw: Socket? = null
            try {
                // имя ищем через DoH — системный DNS провайдер может подменять
                val ip = Doh.lookupA(host)
                raw = Socket()
                vpn.protect(raw)
                raw.tcpNoDelay = true
                val addr = if (ip != null) InetSocketAddress(InetAddress.getByName(ip), 443)
                else InetSocketAddress(host, 443)
                raw.connect(addr, 6000)

                val factory = SSLSocketFactory.getDefault() as SSLSocketFactory
                val ssl = factory.createSocket(raw, host, 443, true) as SSLSocket
                ssl.soTimeout = 10_000
                ssl.startHandshake()

                val key = Base64.encodeToString(ByteArray(16).also { random.nextBytes(it) }, Base64.NO_WRAP)
                val req = "GET /apiws HTTP/1.1\r\n" +
                    "Host: $host\r\n" +
                    "Upgrade: websocket\r\n" +
                    "Connection: Upgrade\r\n" +
                    "Sec-WebSocket-Key: $key\r\n" +
                    "Sec-WebSocket-Version: 13\r\n" +
                    "Sec-WebSocket-Protocol: binary\r\n" +
                    "Origin: https://web.telegram.org\r\n" +
                    "User-Agent: Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/124.0 Mobile Safari/537.36\r\n\r\n"
                val out = ssl.outputStream
                out.write(req.toByteArray(Charsets.US_ASCII))
                out.flush()

                val head = readHttpHead(ssl.inputStream)
                if (!head.startsWith("HTTP/1.1 101")) {
                    log("Telegram: $host ответил «${head.lineSequence().firstOrNull()?.take(40)}»")
                    ssl.close()
                    continue
                }
                ssl.soTimeout = 0
                return Ws(ssl, ssl.inputStream, out, random)
            } catch (e: Exception) {
                log("Telegram: $host — ${e.javaClass.simpleName}")
                try { raw?.close() } catch (_: Exception) {}
            }
        }
        return null
    }

    private fun readHttpHead(inp: InputStream): String {
        val sb = StringBuilder()
        while (sb.length < 8192) {
            val b = inp.read()
            if (b < 0) break
            sb.append(b.toChar())
            if (sb.endsWith("\r\n\r\n")) break
        }
        return sb.toString()
    }

    private class Ws(
        val sock: Socket,
        private val inp: InputStream,
        private val out: OutputStream,
        private val random: SecureRandom
    ) {
        fun send(data: ByteArray) = writeFrame(0x2, data)

        private fun writeFrame(opcode: Int, data: ByteArray) {
            val mask = ByteArray(4).also { random.nextBytes(it) }
            val len = data.size
            val bo = ByteArrayOutputStream(len + 14)
            bo.write(0x80 or opcode)
            when {
                len < 126 -> bo.write(0x80 or len)
                len < 65536 -> {
                    bo.write(0x80 or 126)
                    bo.write(len shr 8); bo.write(len and 0xFF)
                }
                else -> {
                    bo.write(0x80 or 127)
                    for (i in 7 downTo 0) bo.write(((len.toLong() shr (i * 8)) and 0xFF).toInt())
                }
            }
            bo.write(mask)
            val masked = ByteArray(len)
            for (i in 0 until len) masked[i] = (data[i].toInt() xor mask[i % 4].toInt()).toByte()
            bo.write(masked)
            synchronized(out) {
                out.write(bo.toByteArray())
                out.flush()
            }
        }

        /** Следующее сообщение целиком или null, если соединение закрыто. */
        fun recv(): ByteArray? {
            val acc = ByteArrayOutputStream()
            while (true) {
                val b0 = inp.read()
                val b1 = inp.read()
                if (b0 < 0 || b1 < 0) return null
                val fin = (b0 and 0x80) != 0
                val op = b0 and 0x0F
                var len = (b1 and 0x7F).toLong()
                if (len == 126L) {
                    len = ((inp.read() shl 8) or inp.read()).toLong()
                } else if (len == 127L) {
                    len = 0
                    for (i in 0 until 8) len = (len shl 8) or inp.read().toLong()
                }
                var maskKey: ByteArray? = null
                if ((b1 and 0x80) != 0) {
                    maskKey = readFully(inp, 4) ?: return null
                }
                if (len > 16_000_000L) return null
                val payload = readFully(inp, len.toInt()) ?: return null
                if (maskKey != null) {
                    for (i in payload.indices) payload[i] = (payload[i].toInt() xor maskKey[i % 4].toInt()).toByte()
                }
                when (op) {
                    0x8 -> return null
                    0x9 -> writeFrame(0xA, payload)
                    0xA -> {}
                    else -> {
                        acc.write(payload)
                        if (fin) return acc.toByteArray()
                    }
                }
            }
        }

        fun close() {
            try { sock.close() } catch (_: Exception) {}
        }
    }

    // ───────────────────────────── утилиты ─────────────────────────────

    private fun sha256(b: ByteArray): ByteArray = MessageDigest.getInstance("SHA-256").digest(b)

    private fun aes(key: ByteArray, iv: ByteArray, mode: Int): Cipher {
        val c = Cipher.getInstance("AES/CTR/NoPadding")
        c.init(mode, SecretKeySpec(key, "AES"), IvParameterSpec(iv))
        return c
    }

    private fun le32(b: ByteArray, i: Int): Int =
        (b[i].toInt() and 0xFF) or ((b[i + 1].toInt() and 0xFF) shl 8) or
            ((b[i + 2].toInt() and 0xFF) shl 16) or ((b[i + 3].toInt() and 0xFF) shl 24)
}

private fun readFully(inp: InputStream, n: Int): ByteArray? {
    val b = ByteArray(n)
    var r = 0
    while (r < n) {
        val k = inp.read(b, r, n - r)
        if (k < 0) return null
        r += k
    }
    return b
}
