package com.tunavpn.app.ui

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.SweepGradient
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.animation.LinearInterpolator
import androidx.core.graphics.ColorUtils
import kotlin.math.PI
import kotlin.math.sin

/**
 * Большая кнопка: пустое кольцо, по которому течёт белый блик, и светящаяся точка в центре.
 * Выключено — кольцо тёмное, точка тускло светится. Включено — кольцо светлое, точка крупная и яркая.
 */
class PowerButtonView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyle: Int = 0
) : View(context, attrs, defStyle) {

    private val dp = resources.displayMetrics.density
    private var on = false
    private var progress = 0f   // 0 — выкл, 1 — вкл
    private var phase = 0f      // 0..1, бег блика

    private val ringW = 7f * dp
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = ringW }
    private val sheen = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = ringW; strokeCap = Paint.Cap.ROUND
    }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = ringW * 1.6f
        maskFilter = BlurMaskFilter(16f * dp, BlurMaskFilter.Blur.NORMAL)
    }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dotGlow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        maskFilter = BlurMaskFilter(16f * dp, BlurMaskFilter.Blur.NORMAL)
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)

    private val rect = RectF()
    private val matrix = Matrix()
    private var sweep: SweepGradient? = null
    private var cx = 0f
    private var cy = 0f
    private var radius = 0f

    private val phaseAnim = ValueAnimator.ofFloat(0f, 1f).apply {
        interpolator = LinearInterpolator()
        repeatCount = ValueAnimator.INFINITE
        duration = 3200
        addUpdateListener { phase = it.animatedValue as Float; invalidate() }
    }
    private var progAnim: ValueAnimator? = null

    init {
        // BlurMaskFilter требует программной отрисовки
        setLayerType(LAYER_TYPE_SOFTWARE, null)
        isClickable = true
        contentDescription = "Включить или выключить"
    }

    fun setOn(value: Boolean, animate: Boolean = true) {
        if (value == on && progAnim == null) {
            if (!animate) { progress = if (on) 1f else 0f; invalidate() }
            return
        }
        on = value
        phaseAnim.duration = if (on) 1500 else 3200
        val target = if (on) 1f else 0f
        progAnim?.cancel()
        if (!animate) {
            progress = target
            progAnim = null
            invalidate()
            return
        }
        progAnim = ValueAnimator.ofFloat(progress, target).apply {
            duration = 550
            addUpdateListener { progress = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (!phaseAnim.isStarted) phaseAnim.start()
    }

    override fun onDetachedFromWindow() {
        phaseAnim.cancel()
        progAnim?.cancel()
        super.onDetachedFromWindow()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        cx = w / 2f
        cy = h / 2f
        radius = minOf(w, h) / 2f - 30f * dp
        rect.set(cx - radius, cy - radius, cx + radius, cy + radius)
        // комета: длинный хвост и яркая «голова», дальше пусто
        sweep = SweepGradient(
            cx, cy,
            intArrayOf(0x00FFFFFF, 0x00FFFFFF, 0x66FFFFFF, 0xFFFFFFFF.toInt(), 0x00FFFFFF),
            floatArrayOf(0f, 0.45f, 0.8f, 0.97f, 1f)
        )
    }

    override fun onDraw(canvas: Canvas) {
        val p = progress
        val pulse = (sin(phase * 2 * PI * (if (on) 2 else 1)).toFloat() + 1f) / 2f

        // мягкое свечение вокруг кольца
        glow.color = ColorUtils.setAlphaComponent(Color.WHITE, (p * 150 + (1 - p) * pulse * 25).toInt())
        canvas.drawCircle(cx, cy, radius, glow)

        // само кольцо
        ring.color = ColorUtils.blendARGB(0xFF2A2A2F.toInt(), 0xFFD9D9DE.toInt(), p)
        canvas.drawCircle(cx, cy, radius, ring)

        // бегущий блик
        sweep?.let {
            matrix.setRotate(phase * 360f, cx, cy)
            it.setLocalMatrix(matrix)
            sheen.shader = it
            sheen.alpha = if (on) 255 else 230
            canvas.drawArc(rect, 0f, 360f, false, sheen)
        }

        // лёгкая подсветка внутри кольца при включении
        fill.color = ColorUtils.setAlphaComponent(Color.WHITE, (p * 18).toInt())
        canvas.drawCircle(cx, cy, radius - ringW, fill)

        // точка в центре
        val r = (10f + 12f * p) * dp + pulse * 2f * dp * (0.4f + p)
        dotGlow.color = ColorUtils.setAlphaComponent(Color.WHITE, (60 + 170 * p + 30 * pulse).toInt().coerceAtMost(255))
        canvas.drawCircle(cx, cy, r * 1.15f, dotGlow)
        dot.color = ColorUtils.blendARGB(0xFF8D8D94.toInt(), Color.WHITE, p)
        canvas.drawCircle(cx, cy, r, dot)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> animate().scaleX(0.95f).scaleY(0.95f).setDuration(90).start()
            MotionEvent.ACTION_UP -> {
                animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                performClick()
            }
            MotionEvent.ACTION_CANCEL -> animate().scaleX(1f).scaleY(1f).setDuration(120).start()
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }
}
