package com.tunavpn.app.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.tunavpn.app.R
import com.tunavpn.app.Strategy

class StrategyAdapter(
    private val items: List<Strategy>,
    selectedId: String,
    private val onSelect: (Strategy) -> Unit
) : RecyclerView.Adapter<StrategyAdapter.VH>() {

    var selectedId: String = selectedId
        set(v) {
            field = v
            notifyDataSetChanged()
        }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val name: TextView = v.findViewById(R.id.tvName)
        val desc: TextView = v.findViewById(R.id.tvDesc)
        val dot: View = v.findViewById(R.id.dot)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_strategy, parent, false))

    override fun onBindViewHolder(h: VH, position: Int) {
        val st = items[position]
        val selected = st.id == selectedId
        h.name.text = st.name
        h.desc.text = st.description
        h.itemView.setBackgroundResource(if (selected) R.drawable.bg_card_selected else R.drawable.bg_card)
        h.dot.setBackgroundResource(if (selected) R.drawable.dot_on else R.drawable.dot_off)
        h.itemView.setOnClickListener {
            selectedId = st.id
            onSelect(st)
        }
    }

    override fun getItemCount() = items.size
}
