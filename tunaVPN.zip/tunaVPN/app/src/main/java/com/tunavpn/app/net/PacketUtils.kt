package com.tunavpn.app.net

import java.net.InetAddress

object PacketUtils {

    const val FLAG_FIN = 0x01
    const val FLAG_SYN = 0x02
    const val FLAG_RST = 0x04
    const val FLAG_PSH = 0x08
    const val FLAG_ACK = 0x10

    private fun u8(b: ByteArray, i: Int) = b[i].toInt() and 0xFF
    private fun u16(b: ByteArray, i: Int) = (u8(b, i) shl 8) or u8(b, i + 1)
    private fun u32(b: ByteArray, i: Int): Long =
        (u8(b, i).toLong() shl 24) or (u8(b, i + 1).toLong() shl 16) or
            (u8(b, i + 2).toLong() shl 8) or u8(b, i + 3).toLong()

    fun ipVersion(b: ByteArray) = u8(b, 0) shr 4
    fun ipProto(b: ByteArray) = u8(b, 9)
    fun ipHeaderLen(b: ByteArray) = (u8(b, 0) and 0x0F) * 4
    fun ipTotalLen(b: ByteArray) = minOf(u16(b, 2), b.size)
    fun ipSrc(b: ByteArray): ByteArray = b.copyOfRange(12, 16)
    fun ipDst(b: ByteArray): ByteArray = b.copyOfRange(16, 20)

    fun srcPort(b: ByteArray, ipHL: Int) = u16(b, ipHL)
    fun dstPort(b: ByteArray, ipHL: Int) = u16(b, ipHL + 2)

    fun tcpSeq(b: ByteArray, ipHL: Int) = u32(b, ipHL + 4)
    fun tcpAck(b: ByteArray, ipHL: Int) = u32(b, ipHL + 8)
    fun tcpFlags(b: ByteArray, ipHL: Int) = u8(b, ipHL + 13)
    fun tcpWindow(b: ByteArray, ipHL: Int) = u16(b, ipHL + 14)
    fun tcpHeaderLen(b: ByteArray, ipHL: Int) = (u8(b, ipHL + 12) shr 4) * 4

    fun tcpPayload(b: ByteArray, ipHL: Int): ByteArray {
        val start = ipHL + tcpHeaderLen(b, ipHL)
        val end = ipTotalLen(b)
        return if (start in 0 until end) b.copyOfRange(start, end) else ByteArray(0)
    }

    fun udpPayload(b: ByteArray, ipHL: Int): ByteArray {
        val start = ipHL + 8
        val end = ipTotalLen(b)
        return if (start in 0..end) b.copyOfRange(start, end) else ByteArray(0)
    }

    fun ipString(b: ByteArray): String = InetAddress.getByAddress(b).hostAddress ?: ""

    fun buildTcp(
        srcIp: ByteArray, dstIp: ByteArray, srcPort: Int, dstPort: Int,
        seq: Long, ack: Long, flags: Int, window: Int = 65535,
        payload: ByteArray = ByteArray(0), options: ByteArray = ByteArray(0)
    ): ByteArray {
        val tcpHL = 20 + options.size
        val tcpLen = tcpHL + payload.size
        val total = 20 + tcpLen
        val b = ByteArray(total)
        b[0] = 0x45
        put16(b, 2, total)
        b[6] = 0x40  // DF
        b[8] = 64
        b[9] = 6
        srcIp.copyInto(b, 12)
        dstIp.copyInto(b, 16)

        val t = 20
        put16(b, t, srcPort)
        put16(b, t + 2, dstPort)
        put32(b, t + 4, seq)
        put32(b, t + 8, ack)
        b[t + 12] = ((tcpHL / 4) shl 4).toByte()
        b[t + 13] = flags.toByte()
        put16(b, t + 14, window.coerceIn(0, 65535))
        options.copyInto(b, t + 20)
        payload.copyInto(b, t + tcpHL)

        put16(b, 10, checksum(b, 0, 20, null))
        put16(b, t + 16, checksum(b, t, tcpLen, pseudo(srcIp, dstIp, 6, tcpLen)))
        return b
    }

    fun buildUdp(
        srcIp: ByteArray, dstIp: ByteArray, srcPort: Int, dstPort: Int, payload: ByteArray
    ): ByteArray {
        val udpLen = 8 + payload.size
        val total = 20 + udpLen
        val b = ByteArray(total)
        b[0] = 0x45
        put16(b, 2, total)
        b[6] = 0x40
        b[8] = 64
        b[9] = 17
        srcIp.copyInto(b, 12)
        dstIp.copyInto(b, 16)

        val u = 20
        put16(b, u, srcPort)
        put16(b, u + 2, dstPort)
        put16(b, u + 4, udpLen)
        payload.copyInto(b, u + 8)

        put16(b, 10, checksum(b, 0, 20, null))
        var c = checksum(b, u, udpLen, pseudo(srcIp, dstIp, 17, udpLen))
        if (c == 0) c = 0xFFFF
        put16(b, u + 6, c)
        return b
    }

    /** ICMP «порт недоступен» в ответ на исходный IP-пакет (для быстрого отказа от QUIC). */
    fun buildIcmpPortUnreachable(orig: ByteArray): ByteArray {
        val ipHL = ipHeaderLen(orig)
        val quoteLen = minOf(ipHL + 8, orig.size)
        val icmpLen = 8 + quoteLen
        val total = 20 + icmpLen
        val b = ByteArray(total)
        b[0] = 0x45
        put16(b, 2, total)
        b[8] = 64
        b[9] = 1
        // отправитель — тот, к кому обращались; получатель — исходный отправитель
        orig.copyOfRange(16, 20).copyInto(b, 12)
        orig.copyOfRange(12, 16).copyInto(b, 16)
        b[20] = 3  // destination unreachable
        b[21] = 3  // port unreachable
        orig.copyInto(b, 28, 0, quoteLen)
        put16(b, 10, checksum(b, 0, 20, null))
        put16(b, 22, checksum(b, 20, icmpLen, null))
        return b
    }

    fun mssOption(mss: Int): ByteArray =
        byteArrayOf(2, 4, ((mss shr 8) and 0xFF).toByte(), (mss and 0xFF).toByte())

    private fun pseudo(src: ByteArray, dst: ByteArray, proto: Int, len: Int): ByteArray {
        val p = ByteArray(12)
        src.copyInto(p, 0)
        dst.copyInto(p, 4)
        p[9] = proto.toByte()
        p[10] = ((len shr 8) and 0xFF).toByte()
        p[11] = (len and 0xFF).toByte()
        return p
    }

    private fun checksum(b: ByteArray, off: Int, len: Int, pseudo: ByteArray?): Int {
        var sum = 0L
        if (pseudo != null) {
            var i = 0
            while (i < pseudo.size) {
                sum += (u8(pseudo, i) shl 8) or u8(pseudo, i + 1)
                i += 2
            }
        }
        var i = off
        val end = off + len
        while (i + 1 < end) {
            sum += (u8(b, i) shl 8) or u8(b, i + 1)
            i += 2
        }
        if (i < end) sum += u8(b, i) shl 8
        while (sum shr 16 != 0L) sum = (sum and 0xFFFF) + (sum shr 16)
        return (sum.inv() and 0xFFFF).toInt()
    }

    private fun put16(b: ByteArray, i: Int, v: Int) {
        b[i] = ((v shr 8) and 0xFF).toByte()
        b[i + 1] = (v and 0xFF).toByte()
    }

    private fun put32(b: ByteArray, i: Int, v: Long) {
        b[i] = ((v shr 24) and 0xFF).toByte()
        b[i + 1] = ((v shr 16) and 0xFF).toByte()
        b[i + 2] = ((v shr 8) and 0xFF).toByte()
        b[i + 3] = (v and 0xFF).toByte()
    }
}
