package com.tunavpn.app

enum class Method { AUTO, SPLIT, SPLIT_SNI, TLSREC, TLSREC_SPLIT, OOB, DISORDER }

data class Strategy(
    val id: String,
    val name: String,
    val description: String,
    val method: Method
)

object Strategies {

    val ALL: List<Strategy> = listOf(
        Strategy("auto", "Авто", "Сам подбирает рабочий способ для каждого сервера", Method.AUTO),
        Strategy("split_sni", "Split SNI", "Режет запрос на два пакета посреди имени сайта", Method.SPLIT_SNI),
        Strategy("tlsrec", "TLS Record", "Дробит TLS-запись на две, имя сайта не видно целиком", Method.TLSREC),
        Strategy("tlsrec_split", "TLS Record + Split", "Дробит запись и отправляет её частями", Method.TLSREC_SPLIT),
        Strategy("oob", "OOB", "Вставляет «срочный» байт между частями запроса", Method.OOB),
        Strategy("disorder", "Disorder", "Меняет порядок частей запроса, старт чуть медленнее", Method.DISORDER),
        Strategy("split", "Split 1", "Отделяет первый байт запроса", Method.SPLIT)
    )

    /** Порядок перебора для режима «Авто». */
    val AUTO_ORDER: List<Method> = listOf(
        Method.SPLIT_SNI, Method.TLSREC, Method.TLSREC_SPLIT,
        Method.OOB, Method.DISORDER, Method.SPLIT
    )

    fun byId(id: String): Strategy = ALL.firstOrNull { it.id == id } ?: ALL[0]
}
