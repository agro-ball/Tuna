# tunaVPN

Лёгкий обход блокировок YouTube и Telegram на Android. Свой сервер не нужен:
трафик не уходит на сторонние серверы, приложение меняет способ отправки запросов прямо на телефоне.

Основа: [ezxidze/ZapretDroid](https://github.com/ezxidze/ZapretDroid) (MIT). Ядро переписано.

## Сборка APK (Android Studio)
1. File → Open → выбрать папку проекта, дождаться синхронизации Gradle (первый раз качает SDK 34 — согласись).
2. Build → Build Bundle(s) / APK(s) → Build APK(s).
3. Файл: `app/build/outputs/apk/debug/app-debug.apk`.

## Как пользоваться
1. Включи кнопку, разреши VPN-подключение.
2. YouTube: выбери протокол (начни с «Авто»). Если не грузит — смени протокол и снова проверь.
3. Telegram: нажми «Подключить Telegram» — откроется Telegram с готовым прокси, подтверди.
4. Если что-то не работает — внизу экрана «Журнал»: пришли скриншот.

## Что внутри
- `net/TcpRelay.kt` — TCP между туннелем и серверами (порядок, окно, MSS).
- `net/DpiBypass.kt` — split / TLS-record / OOB / disorder (без root).
- `net/UdpRelay.kt` + `net/Doh.kt` — DNS через DoH, QUIC отклоняется (YouTube идёт по TCP).
- `net/TelegramWsProxy.kt` — MTProto-прокси 127.0.0.1:1443 → WebSocket к kwsN.web.telegram.org.
